Listeners
=========


.. module:: sqlalchemy_utils.listeners

Automatic data coercion
-----------------------

.. autofunction:: force_auto_coercion


Instant defaults
----------------

.. autofunction:: force_instant_defaults


Many-to-many orphan deletion
----------------------------

.. autofunction:: auto_delete_orphans
