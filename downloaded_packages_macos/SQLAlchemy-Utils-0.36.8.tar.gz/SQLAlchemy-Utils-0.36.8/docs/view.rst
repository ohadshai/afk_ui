View utilities
==============

.. module:: sqlalchemy_utils


create_view
-----------

.. autofunction:: create_view


create_materialized_view
------------------------

.. autofunction:: create_materialized_view


refresh_materialized_view
-------------------------

.. autofunction:: refresh_materialized_view
